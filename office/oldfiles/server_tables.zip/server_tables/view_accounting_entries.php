<?php session_start();
      require_once('../config/database_functions.php'); 
      $uid2 = $_SESSION['uid'];
 
/*
 * DataTables example server-side processing script.
 *
 * Please note that this script is intentionally extremely simple to show how
 * server-side processing can be implemented, and probably shouldn't be used as
 * the basis for a large complex system. It is suitable for simple use cases as
 * for learning.
 *
 * See http://datatables.net/usage/server-side for full details on the server-
 * side processing requirements of DataTables.
 *
 * @license MIT - http://datatables.net/license_mit
 */
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
 
// DB table to use
$table = 'accounting_entries';
 
// Table's primary key
$primaryKey = 'id';
 
// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
    // array( 'db' => 'unique_id', 'dt' => 0 ),
    array( 'db' => 'item_id', 'dt' => 0 ),
    array(
       'db' => 'item_id',
       'dt' => 1,
       'formatter' => function( $d, $row){
            $user_det = get_one_row_from_one_table_by_id('accounting_items','item_id',$d,'date_added');
            $item_name = $user_det['item_name'];
           return $item_name;
        }
     ),
    array( 
      'db' => 'item_description',
      'dt' => 2,
      'formatter' => function($d,$row){
          if($d == ""){
              return 'nill';
          }else{
              return $d;
          }
      }
     ),
    array( 
      'db' => 'transaction_type',
      'dt' => 3,
        'formatter' => function( $d, $row){

            if($d == 'debit'){
              return "<span style='color:red;'>".$d."</span>";
            }else{
              return "<span style='color:green;'>".$d."</span>";
            }

        }

    ),
    array( 'db' => 'amount', 'dt' => 4 ),
    array(
        'db' => 'date_of_transaction', 
        'dt' => 5,
        'formatter' => function( $d, $row ) {
            // return date( 'jS M y', strtotime($d));
            return date( 'd F Y', strtotime($d));
        }
     ),
  
    array( 
      'db' => 'date_entered', 
      'dt' => 7,
      'formatter' => function( $d, $row ) {
            // return date( 'jS M y', strtotime($d));
            return date( 'd F Y', strtotime($d));
        }
       ),
      array(
        'db' => 'entered_by',
        'dt' => 6,
        'formatter' => function( $d, $row){

            $user_det = get_one_row_from_one_table_by_id('users','unique_id',$d,'date_created');
            $ffname = $user_det['fname'].' '.$user_det['lname'];
            $phone = $user_det['phone'];

           return $ffname.'('.$phone.')';

        }
    )


  
  
);
 
// SQL server connection information
$sql_details = array(
    'user' => USER,
    'pass' => PASSWORD,
    'db'   => DB_NAME,
    'host' => HOST
);
 
// $sql_details = array(
//     'user' => 'root',
//     'pass' => '',
//     'db'   => 'churchworld1',
//     'host' => 'localhost'
// );
 
 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
 
require( 'ssp.class.php' );
 
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);